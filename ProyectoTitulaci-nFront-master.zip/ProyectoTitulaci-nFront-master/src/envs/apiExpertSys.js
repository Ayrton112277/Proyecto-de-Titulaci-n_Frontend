export const URLApiExpertSys = "http://localhost:8080";

export const URLChatExpertSys = "http://localhost:8081";