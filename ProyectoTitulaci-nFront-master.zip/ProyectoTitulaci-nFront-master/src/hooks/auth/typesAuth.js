
export const types ={
    loginUser:"[Auth] user",
    loginPsych: "[Auth] psych",
    logout: "[Auth] logout"
}