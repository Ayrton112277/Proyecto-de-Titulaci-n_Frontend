import React from 'react';

export const ChatPsych = () => {
    return (
        <div>
        
        </div>
    );
};