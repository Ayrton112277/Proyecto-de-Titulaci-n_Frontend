import React from 'react';
import {Statistics} from "./Statistics";






export const PsychHome = () => {
    return (
        <div className="p-2">
            <Statistics/>
        </div>
    );
};
