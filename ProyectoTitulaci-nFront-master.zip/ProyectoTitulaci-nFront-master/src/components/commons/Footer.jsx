import React from 'react';
import './footer-styles.css';
export const Footer = () => {
    return (
        <>
            <footer className="text-center  footer" >
                <div className="text-center p-3" >
                     Copyright: Expert System© 2022.
                </div>
            </footer>
        </>
    );
};

